import json
import os
import time
from datetime import datetime

import functions_framework
import requests
from google.cloud import billing_budgets_v1
from google.cloud import secretmanager
from google.cloud import monitoring_v3
from google.cloud import storage

# --- 定数設定 ---
# 費用を取得するためのメトリクス名
METRIC_TYPE = "billing.googleapis.com/billing/total_cost"

def get_secret(secret_id):
    client = secretmanager.SecretManagerServiceClient()
    name = secret_id if "/versions/" in secret_id else f"{secret_id}/versions/latest"
    response = client.access_secret_version(request={"name": name})
    return response.payload.data.decode("UTF-8")

def get_actual_cost(project_id):
    """
    Cloud Monitoring API を使用して、当月（1日から現在まで）の累積費用を取得する。
    """
    client = monitoring_v3.MetricServiceClient()
    project_name = f"projects/{project_id}"
    
    # 当月の開始時刻を取得
    now = datetime.utcnow()
    start_time = datetime(now.year, now.month, 1)
    
    interval = monitoring_v3.TimeInterval({
        "end_time": {"seconds": int(time.time())},
        "start_time": {"seconds": int(start_time.timestamp())},
    })

    # 合計費用メトリクスを取得
    results = client.list_time_series(
        request={
            "name": project_name,
            "filter": f'metric.type = "{METRIC_TYPE}"',
            "interval": interval,
            "view": monitoring_v3.ListTimeSeriesRequest.TimeSeriesView.FULL,
        }
    )

    total_cost = 0.0
    for result in results:
        for point in result.points:
            total_cost += point.value.double_value
            
    return total_cost

def get_last_notified_threshold(bucket_name, budget_id):
    """GCSから最後に通知したしきい値を取得する"""
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(f"state/{budget_id}/last_threshold")
        if blob.exists():
            return float(blob.download_as_string())
    except:
        pass
    return 0.0

def save_notified_threshold(bucket_name, budget_id, threshold):
    """GCSに通知済みのしきい値を保存する"""
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(f"state/{budget_id}/last_threshold")
        blob.upload_from_string(str(threshold))
    except Exception as e:
        print(f"Failed to save state to GCS: {e}")

@functions_framework.http
def check_budgets(request):
    try:
        is_test = request.args.get("test") == "true"
        billing_account_id = os.environ.get("BILLING_ACCOUNT_ID")
        slack_secret_id = os.environ.get("SLACK_SECRET_ID")
        state_bucket = os.environ.get("STATE_BUCKET") # main.tf で追加予定
        admin_project_id = os.environ.get("ADMIN_PROJECT_ID")

        if not all([billing_account_id, slack_secret_id, state_bucket, admin_project_id]):
            return ("Configuration Error", 500)

        slack_webhook_url = get_secret(slack_secret_id)
        budget_client = billing_budgets_v1.BudgetServiceClient()
        parent = f"billingAccounts/{billing_account_id}"
        budgets = budget_client.list_budgets(parent=parent)

        notifications_sent = 0
        for budget in budgets:
            # 1. 予算設定の取得
            budget_limit = float(budget.amount.specified_amount.units)
            budget_id = budget.name.split("/")[-1]
            
            # 2. 実績費用の取得 (テスト時は120%とする)
            if is_test:
                actual_cost = budget_limit * 1.2
            else:
                # 予算フィルタからプロジェクトIDを特定（簡易的な実装）
                # 通常は projects/数字 だが、Monitoring API 用にプロジェクトIDが必要
                # ここでは Admin プロジェクトの費用を代表として取得する例とする
                # 本来は各子プロジェクトごとにループ回す設計が理想
                actual_cost = get_actual_cost(admin_project_id)

            current_percent = (actual_cost / budget_limit) * 100 if budget_limit > 0 else 0

            # 3. 超過している最大しきい値を特定
            thresholds = sorted([t.threshold_percent * 100 for t in budget.threshold_rules], reverse=True)
            triggered_threshold = 0
            for t in thresholds:
                if current_percent >= t:
                    triggered_threshold = t
                    break

            # 4. スパム防止判定 (前回の通知しきい値より高い場合のみ通知)
            last_threshold = get_last_notified_threshold(state_bucket, budget_id)
            
            if triggered_threshold > last_threshold or is_test:
                message = (
                    f"🚨 *GCP予算超過アラート: {budget.display_name}*\n"
                    f"> 現在の消費率が *{current_percent:.1f}%* に達しました。\n"
                    f"> (判定しきい値: {triggered_threshold:.0f}%)\n"
                    f"> 実績費用: *{actual_cost:,.0f} JPY*\n"
                    f"> 予算設定: *{budget_limit:,.0f} JPY*\n"
                    f"{'🧪 [TEST MODE]' if is_test else ''}"
                )
                
                requests.post(slack_webhook_url, json={"text": message}, timeout=10)
                save_notified_threshold(state_bucket, budget_id, triggered_threshold)
                notifications_sent += 1
                if is_test: break

        return (f"Done. Sent {notifications_sent} notifications.", 200)

    except Exception as e:
        print(f"Error: {e}")
        return (str(e), 500)
